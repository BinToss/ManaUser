Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents txtSymbol As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtPosition As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents picZoom As System.Windows.Forms.PictureBox
    Friend WithEvents picTex As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox0 As System.Windows.Forms.TextBox
    Friend WithEvents itmOpen As System.Windows.Forms.MenuItem
    Friend WithEvents itmExit As System.Windows.Forms.MenuItem
    Friend WithEvents itmSave As System.Windows.Forms.MenuItem
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuTools As System.Windows.Forms.MenuItem
    Friend WithEvents itmSelect As System.Windows.Forms.MenuItem
    Friend WithEvents itmMakeTex As System.Windows.Forms.MenuItem
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents itmMakeBmp As System.Windows.Forms.MenuItem
    Friend WithEvents itmHeight As System.Windows.Forms.MenuItem
    Friend WithEvents itmSaveAs As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents itmNew As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents itmRevert As System.Windows.Forms.MenuItem
    Friend WithEvents itmCopy As System.Windows.Forms.MenuItem
    Friend WithEvents itmPaste As System.Windows.Forms.MenuItem
    Friend WithEvents itmPrev As System.Windows.Forms.MenuItem
    Friend WithEvents itmNext As System.Windows.Forms.MenuItem
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents mnuNav As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.itmNew = New System.Windows.Forms.MenuItem()
        Me.itmOpen = New System.Windows.Forms.MenuItem()
        Me.itmSave = New System.Windows.Forms.MenuItem()
        Me.itmSaveAs = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.itmExit = New System.Windows.Forms.MenuItem()
        Me.mnuTools = New System.Windows.Forms.MenuItem()
        Me.itmHeight = New System.Windows.Forms.MenuItem()
        Me.itmSelect = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.itmMakeBmp = New System.Windows.Forms.MenuItem()
        Me.itmMakeTex = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.itmRevert = New System.Windows.Forms.MenuItem()
        Me.itmCopy = New System.Windows.Forms.MenuItem()
        Me.itmPaste = New System.Windows.Forms.MenuItem()
        Me.mnuNav = New System.Windows.Forms.MenuItem()
        Me.itmPrev = New System.Windows.Forms.MenuItem()
        Me.itmNext = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox0 = New System.Windows.Forms.TextBox()
        Me.txtSymbol = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.picZoom = New System.Windows.Forms.PictureBox()
        Me.picTex = New System.Windows.Forms.PictureBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuTools, Me.mnuNav})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.itmNew, Me.itmOpen, Me.itmSave, Me.itmSaveAs, Me.MenuItem3, Me.itmExit})
        Me.mnuFile.Text = "&File"
        '
        'itmNew
        '
        Me.itmNew.Index = 0
        Me.itmNew.Shortcut = System.Windows.Forms.Shortcut.CtrlN
        Me.itmNew.Text = "&New"
        '
        'itmOpen
        '
        Me.itmOpen.Index = 1
        Me.itmOpen.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.itmOpen.Text = "&Open"
        '
        'itmSave
        '
        Me.itmSave.Enabled = False
        Me.itmSave.Index = 2
        Me.itmSave.Shortcut = System.Windows.Forms.Shortcut.CtrlS
        Me.itmSave.Text = "&Save"
        '
        'itmSaveAs
        '
        Me.itmSaveAs.Enabled = False
        Me.itmSaveAs.Index = 3
        Me.itmSaveAs.Shortcut = System.Windows.Forms.Shortcut.F12
        Me.itmSaveAs.Text = "Save &As..."
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 4
        Me.MenuItem3.Text = "-"
        '
        'itmExit
        '
        Me.itmExit.Index = 5
        Me.itmExit.Shortcut = System.Windows.Forms.Shortcut.AltF4
        Me.itmExit.Text = "E&xit"
        '
        'mnuTools
        '
        Me.mnuTools.Index = 1
        Me.mnuTools.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.itmHeight, Me.itmSelect, Me.MenuItem1, Me.itmMakeBmp, Me.itmMakeTex, Me.MenuItem2, Me.itmRevert, Me.itmCopy, Me.itmPaste})
        Me.mnuTools.Text = "&Tools"
        '
        'itmHeight
        '
        Me.itmHeight.Index = 0
        Me.itmHeight.Text = "&Height: X (Change)"
        '
        'itmSelect
        '
        Me.itmSelect.Index = 1
        Me.itmSelect.Text = "&Select New TEX"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 2
        Me.MenuItem1.Text = "-"
        '
        'itmMakeBmp
        '
        Me.itmMakeBmp.Index = 3
        Me.itmMakeBmp.Text = "Make &BMP from TEX "
        '
        'itmMakeTex
        '
        Me.itmMakeTex.Index = 4
        Me.itmMakeTex.Text = "Make &TEX from BMP"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 5
        Me.MenuItem2.Text = "-"
        '
        'itmRevert
        '
        Me.itmRevert.Enabled = False
        Me.itmRevert.Index = 6
        Me.itmRevert.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftZ
        Me.itmRevert.Text = "&Revert Symbol"
        '
        'itmCopy
        '
        Me.itmCopy.Enabled = False
        Me.itmCopy.Index = 7
        Me.itmCopy.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftC
        Me.itmCopy.Text = "&Copy Symbol"
        '
        'itmPaste
        '
        Me.itmPaste.Enabled = False
        Me.itmPaste.Index = 8
        Me.itmPaste.Shortcut = System.Windows.Forms.Shortcut.CtrlShiftV
        Me.itmPaste.Text = "&Paste Symbol"
        '
        'mnuNav
        '
        Me.mnuNav.Enabled = False
        Me.mnuNav.Index = 2
        Me.mnuNav.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.itmPrev, Me.itmNext})
        Me.mnuNav.Text = "Na&vigation"
        '
        'itmPrev
        '
        Me.itmPrev.Enabled = False
        Me.itmPrev.Index = 0
        Me.itmPrev.Shortcut = System.Windows.Forms.Shortcut.F10
        Me.itmPrev.Text = "&Previous"
        '
        'itmNext
        '
        Me.itmNext.Enabled = False
        Me.itmNext.Index = 1
        Me.itmNext.Shortcut = System.Windows.Forms.Shortcut.F11
        Me.itmNext.Text = "&Next"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(112, 24)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(64, 20)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = ""
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(112, 48)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(64, 20)
        Me.TextBox2.TabIndex = 5
        Me.TextBox2.Text = ""
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(112, 72)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(64, 20)
        Me.TextBox3.TabIndex = 7
        Me.TextBox3.Text = ""
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(112, 96)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(64, 20)
        Me.TextBox4.TabIndex = 9
        Me.TextBox4.Text = ""
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(112, 120)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(64, 20)
        Me.TextBox5.TabIndex = 11
        Me.TextBox5.Text = ""
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(112, 144)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(64, 20)
        Me.TextBox6.TabIndex = 13
        Me.TextBox6.Text = ""
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(112, 168)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(64, 20)
        Me.TextBox7.TabIndex = 15
        Me.TextBox7.Text = ""
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(112, 200)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(64, 20)
        Me.TextBox8.TabIndex = 17
        Me.TextBox8.Text = ""
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(112, 224)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(64, 20)
        Me.TextBox9.TabIndex = 19
        Me.TextBox9.Text = ""
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(112, 248)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(64, 20)
        Me.TextBox10.TabIndex = 21
        Me.TextBox10.Text = ""
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(112, 272)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(64, 20)
        Me.TextBox11.TabIndex = 23
        Me.TextBox11.Text = ""
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(112, 296)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(64, 20)
        Me.TextBox12.TabIndex = 25
        Me.TextBox12.Text = ""
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(112, 320)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(64, 20)
        Me.TextBox13.TabIndex = 27
        Me.TextBox13.Text = ""
        '
        'TextBox0
        '
        Me.TextBox0.Location = New System.Drawing.Point(112, 0)
        Me.TextBox0.Name = "TextBox0"
        Me.TextBox0.Size = New System.Drawing.Size(64, 20)
        Me.TextBox0.TabIndex = 1
        Me.TextBox0.Text = ""
        '
        'txtSymbol
        '
        Me.txtSymbol.Enabled = False
        Me.txtSymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSymbol.Location = New System.Drawing.Point(112, 352)
        Me.txtSymbol.MaxLength = 1
        Me.txtSymbol.Name = "txtSymbol"
        Me.txtSymbol.Size = New System.Drawing.Size(24, 20)
        Me.txtSymbol.TabIndex = 29
        Me.txtSymbol.Text = ""
        Me.txtSymbol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 352)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Go To &Symbol:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 272)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 16)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "&Trailing Space:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'txtPosition
        '
        Me.txtPosition.Enabled = False
        Me.txtPosition.Location = New System.Drawing.Point(112, 376)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(32, 20)
        Me.txtPosition.TabIndex = 31
        Me.txtPosition.Text = ""
        Me.txtPosition.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 200)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 16)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "&Width:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 224)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 16)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "&Height:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 296)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 16)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Top &Y Position:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 320)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(104, 16)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "&Zero/Unknown:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(8, 248)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 16)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "&Leading Space:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'picZoom
        '
        Me.picZoom.BackColor = System.Drawing.SystemColors.ControlDark
        Me.picZoom.Location = New System.Drawing.Point(184, 6)
        Me.picZoom.Name = "picZoom"
        Me.picZoom.Size = New System.Drawing.Size(130, 130)
        Me.picZoom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picZoom.TabIndex = 27
        Me.picZoom.TabStop = False
        '
        'picTex
        '
        Me.picTex.BackColor = System.Drawing.SystemColors.ControlDark
        Me.picTex.Cursor = System.Windows.Forms.Cursors.Cross
        Me.picTex.Location = New System.Drawing.Point(184, 144)
        Me.picTex.Name = "picTex"
        Me.picTex.Size = New System.Drawing.Size(260, 260)
        Me.picTex.TabIndex = 26
        Me.picTex.TabStop = False
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(56, 120)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 16)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "&6) B L Y:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(56, 96)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 16)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "&5) B L X:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(56, 24)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(56, 16)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "&2) T L Y:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(56, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(56, 16)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "&1) T L X:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(56, 48)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(56, 16)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "&3) T R X:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(56, 168)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(56, 16)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "&8) B R Y:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(56, 144)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(56, 16)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "&7) B R X:"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(56, 72)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(56, 16)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "&4) T R Y:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "doc1"
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(16, 376)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(96, 16)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "Go To &Number:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 409)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.picZoom, Me.Label16, Me.Label9, Me.Label10, Me.Label13, Me.Label14, Me.Label15, Me.Label8, Me.Label11, Me.Label12, Me.picTex, Me.Label7, Me.Label6, Me.Label5, Me.Label4, Me.Label3, Me.txtPosition, Me.Label1, Me.txtSymbol, Me.TextBox0, Me.TextBox13, Me.TextBox12, Me.TextBox11, Me.TextBox10, Me.TextBox9, Me.TextBox8, Me.TextBox7, Me.TextBox6, Me.TextBox5, Me.TextBox4, Me.TextBox3, Me.TextBox2, Me.TextBox1, Me.Label2})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.MainMenu1
        Me.MinimumSize = New System.Drawing.Size(328, 448)
        Me.Name = "frmMain"
        Me.Text = "Font Reader"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim gfxTex As Graphics
    Dim gfxZoom As Graphics
    Dim CropPen = New Pen(Color.Cyan)
    Dim EdgeColor = Color.Blue
    Dim ZoomEdgePen = New Pen(Color.Red)

    Dim FntPath As String
    Dim FntName As String
    Dim TexName As String
    Dim ArcImg As Image
    Dim TexWidth As Int32, TexHeight As Int32
    Dim FntHeight As Single
    Dim FntHead2 As Int32
    Dim FntHead3 As Int32
    Dim FntTail As String

    Dim SelTLX As Integer
    Dim SelTLY As Integer
    Dim SelBRX As Integer
    Dim SelBRY As Integer
    Dim NoUpdateZoom As Boolean
    Dim MagMoveX As Integer
    Dim MagMoveY As Integer
    Dim HeightDiff As Integer

    Dim m_ArcField(247, 13) As Single
    Dim m_Field(247, 13) As Single
    Dim m_ClipField(13) As Single
    Dim m_Position As Integer
    Dim m_MoveCount As Integer

    Const m_LastChar As Integer = 247

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        gfxTex = picTex.CreateGraphics
        gfxZoom = picZoom.CreateGraphics
        gfxZoom.InterpolationMode = Drawing.Drawing2D.InterpolationMode.NearestNeighbor

        SelTLX = -1
        SelTLY = -1

        HeightDiff = Me.Height - 410

        'ArcImg = New Bitmap("C:\Program Files\Morrowind\Data Files\Fonts\century_gothic_font_regular_0_Lod_A.png")
        'picTex.Image = ArcImg
    End Sub

    Private Sub itmOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmOpen.Click
        Dim I As Integer, J As Integer
        Dim Field As Single

        OpenFileDialog1.Title = "Open FNT File"
        OpenFileDialog1.Filter = "Morrowind Font Files (*.FNT)|*.FNT"
        If OpenFileDialog1.ShowDialog <> DialogResult.Cancel Then
            FntPath = OpenFileDialog1.FileName.Substring(0, OpenFileDialog1.FileName.LastIndexOf("\"))
            FntName = OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.LastIndexOf("\") + 1)
            FileOpen(1, FntPath + "\" + FntName, OpenMode.Binary)
            FileGet(1, FntHeight)
            itmHeight.Text = "Height: " + FntHeight.ToString + " (Change)"
            FileGet(1, FntHead2)
            FileGet(1, FntHead3)
            TexName = ("").PadRight(288)
            FileGet(1, TexName)
            TexName = TexName.Substring(0, TexName.IndexOf(Chr(0)))
            For I = 0 To m_LastChar
                For J = 0 To 13
                    FileGet(1, m_ArcField(I, J))
                Next
            Next
            m_Field = m_ArcField.Clone
            FntTail = ("").PadRight(444)
            FileGet(1, FntTail)
            FileClose(1)
            m_MoveCount = 0
            ArcImg = ReadTex(FntPath + "\" + TexName + ".tex", True)
            ResizePicture(ArcImg.Width, ArcImg.Height)
            picTex.Image = ArcImg.Clone
            m_Position = 0
            EnableSave(True)
            LoadData()
        End If
    End Sub

    Private Function ReadTex(ByVal FileName As String, ByVal Border As Boolean) As Image
        Dim TexBM As Bitmap, TexImg As Image, TexPixel As Byte
        Dim TexCol As Integer, TexRow As Integer
        FileOpen(1, FileName, OpenMode.Binary)
        FileGet(1, TexWidth)
        FileGet(1, TexHeight)
        If Border Then
            TexBM = New Bitmap(TexWidth + 4, TexHeight + 4)
            For TexRow = 0 To TexHeight + 3
                TexBM.SetPixel(0, TexRow, Color.Blue)
                TexBM.SetPixel(1, TexRow, Color.Blue)
                TexBM.SetPixel(TexHeight + 2, TexRow, EdgeColor)
                TexBM.SetPixel(TexHeight + 3, TexRow, EdgeColor)
            Next
            For TexCol = 0 To TexWidth + 3
                TexBM.SetPixel(TexCol, 0, Color.Blue)
                TexBM.SetPixel(TexCol, 1, Color.Blue)
                TexBM.SetPixel(TexCol, TexWidth + 2, EdgeColor)
                TexBM.SetPixel(TexCol, TexWidth + 3, EdgeColor)
            Next
        Else
            TexBM = New Bitmap(TexWidth, TexHeight)
        End If
        For TexRow = 0 To TexHeight - 1
            For TexCol = 0 To TexWidth - 1
                Seek(1, Seek(1) + 3) 'Skip 3 bytes
                FileGet(1, TexPixel)
                If Border Then
                    TexBM.SetPixel(TexCol + 2, TexRow + 2, Color.FromArgb(TexPixel, TexPixel, TexPixel))
                Else
                    TexBM.SetPixel(TexCol, TexRow, Color.FromArgb(TexPixel, TexPixel, TexPixel))
                End If
            Next
        Next
        FileClose(1)
        TexImg = TexBM
        Return TexBM
    End Function

    Private Sub itmSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmSave.Click
        SaveCurrent()
        m_ArcField = m_Field.Clone
        SaveFnt(FntPath + "\" + FntName)
    End Sub

    Private Sub itmSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmSaveAs.Click
        SaveFileDialog1.Title = "Save FNT as..."
        SaveFileDialog1.Filter = "Morrowind Font Texture (*.FNT)|*.FNT"
        SaveFileDialog1.FileName = FntPath + "\" + FntName
        If SaveFileDialog1.ShowDialog <> DialogResult.Cancel Then
            SaveCurrent()
            m_ArcField = m_Field.Clone
            FntPath = SaveFileDialog1.FileName.Substring(0, SaveFileDialog1.FileName.LastIndexOf("\"))
            FntName = SaveFileDialog1.FileName.Substring(SaveFileDialog1.FileName.LastIndexOf("\") + 1)
            SaveFnt(FntPath + "\" + FntName)
        End If
    End Sub

    Private Sub SaveFnt(ByVal FileName As String)
        Dim TEXOut As String
        Dim Pos As Integer, Fld As Integer

        If FileSystem.Dir(FileName) <> "" Then
            Kill(FileName)
        End If

        FileOpen(1, FileName, OpenMode.Binary)
        FilePut(1, FntHeight)
        FilePut(1, FntHead2)
        FilePut(1, FntHead3)
        TEXOut = TexName.PadRight(288, Chr(0))
        FilePut(1, TEXOut)
        For Pos = 0 To 247
            For Fld = 0 To 13
                FilePut(1, m_Field(Pos, Fld))
            Next
        Next
        FilePut(1, FntTail)
        FileClose(1)
    End Sub

    Private Sub LoadData()
        TextBox0.Text = (m_Field(m_Position, 0) * TexWidth).ToString
        TextBox1.Text = (m_Field(m_Position, 1) * TexHeight).ToString
        TextBox2.Text = (m_Field(m_Position, 2) * TexWidth).ToString
        TextBox3.Text = (m_Field(m_Position, 3) * TexHeight).ToString
        TextBox4.Text = (m_Field(m_Position, 4) * TexWidth).ToString
        TextBox5.Text = (m_Field(m_Position, 5) * TexHeight).ToString
        TextBox6.Text = (m_Field(m_Position, 6) * TexWidth).ToString
        TextBox7.Text = (m_Field(m_Position, 7) * TexHeight).ToString
        TextBox8.Text = m_Field(m_Position, 8).ToString
        TextBox9.Text = m_Field(m_Position, 9).ToString
        TextBox10.Text = m_Field(m_Position, 10).ToString
        TextBox11.Text = m_Field(m_Position, 11).ToString
        TextBox12.Text = m_Field(m_Position, 12).ToString
        TextBox13.Text = m_Field(m_Position, 13).ToString
        txtSymbol.Text = Chr(m_Position)
        txtPosition.Text = m_Position.ToString

        itmPrev.Enabled = (m_Position > 0)
        itmNext.Enabled = (m_Position < m_LastChar)

        Mark(m_Field(m_Position, 0) * TexWidth, m_Field(m_Position, 1) * TexHeight, _
                m_Field(m_Position, 6) * TexWidth, m_Field(m_Position, 7) * TexHeight)
    End Sub

    Private Sub txtPosition_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPosition.TextChanged
        txtPosition.Text = Val(txtPosition.Text)
        SaveCurrent()
        If Val(txtPosition.Text) >= 0 And Val(txtPosition.Text) <= m_LastChar Then
            m_Position = Val(txtPosition.Text)
            LoadData()
        Else
            Beep()
        End If
    End Sub

    Private Sub txtSymbol_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSymbol.TextChanged
        If txtSymbol.Text <> "" Then
            SaveCurrent()
            If Asc(txtSymbol.Text) >= 0 And Asc(txtSymbol.Text) <= m_LastChar Then
                m_Position = Asc(txtSymbol.Text)
                LoadData()
            Else
                Beep()
            End If
        End If
        txtSymbol.Select(0, 1)
    End Sub

    Private Sub txtSymbol_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtSymbol.Enter
        txtSymbol.Select(0, 1)
    End Sub

    Private Sub txtSymbol_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles txtSymbol.MouseUp
        txtSymbol.Select(0, 1)
    End Sub

    Private Sub picTex_MouseMove(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picTex.MouseMove
        If m_MoveCount < 10 Then
            m_MoveCount += 1
            Exit Sub
        End If
        If (Not picTex.Image Is Nothing) Then
            'CType(picTex.Image, Bitmap).SetPixel(e.X, e.Y, Color.Cyan)
            'picTex.Refresh()
            If NoUpdateZoom Then
                NoUpdateZoom = False
                Exit Sub
            End If
            If SelTLX = -1 Then
                gfxZoom.DrawImage(picTex.Image, New Rectangle(12 - e.X * 6, 12 - e.Y * 6, picTex.Image.Width * 6, picTex.Image.Height * 6))
                gfxZoom.DrawLine(CropPen, 4, 8, 32, 8)
                gfxZoom.DrawLine(CropPen, 8, 4, 8, 32)
                gfxZoom.DrawRectangle(ZoomEdgePen, 0, 0, picZoom.Width - 1, picZoom.Height - 1)
            Else
                SelBRX = e.X : SelBRY = e.Y
                If SelBRX > TexWidth + 2 Then SelBRX = TexWidth + 2
                If SelBRY > TexHeight + 2 Then SelBRY = TexHeight + 2
                If SelBRX < SelTLX Then SelBRX = SelTLX
                If SelBRY < SelTLY Then SelBRY = SelTLY
                Mark(SelTLX - 2, SelTLY - 2, SelBRX - 2, SelBRY - 2)
                gfxZoom.DrawImage(picTex.Image, New Rectangle(12 - SelTLX * 6, 12 - SelTLY * 6, picTex.Image.Width * 6, picTex.Image.Height * 6))
                gfxZoom.DrawRectangle(ZoomEdgePen, 0, 0, picZoom.Width - 1, picZoom.Height - 1)
            End If
        End If
    End Sub

    Private Overloads Sub Mark(ByVal TLX As Integer, ByVal TLY As Integer, ByVal BRX As Integer, ByVal BRY As Integer)
        Dim TexCol As Integer, TexRow As Integer
        Dim TexBM As Bitmap
        Dim Pixel As Color
        TexBM = ArcImg.Clone
        For TexRow = TLY + 2 To BRY + 1
            For TexCol = TLX + 2 To BRX + 1
                Pixel = TexBM.GetPixel(TexCol, TexRow)
                Pixel = Color.FromArgb(255, Pixel.G, 0)
                TexBM.SetPixel(TexCol, TexRow, Pixel)
            Next
        Next
        picTex.Image = TexBM
    End Sub

    Private Sub picTex_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picTex.MouseDown
        If m_MoveCount < 10 Then
            Exit Sub
        End If
        If SelTLX = -1 Then
            If InBounds(e.X, e.Y, 2, 2, TexWidth + 2, TexHeight + 2) Then
                SelTLX = e.X
                SelTLY = e.Y
            Else
                Beep()
            End If
        End If
    End Sub

    Private Sub picTex_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picTex.MouseUp
        If m_MoveCount < 10 Then
            Exit Sub
        End If
        If InBounds(e.X, e.Y, 2, 2, TexWidth + 2, TexHeight + 2) Then
            TextBox0.Text = SelTLX - 2
            TextBox1.Text = SelTLY - 2
            TextBox2.Text = SelBRX - 2
            TextBox3.Text = SelTLY - 2
            TextBox4.Text = SelTLX - 2
            TextBox5.Text = SelBRY - 2
            TextBox6.Text = SelBRX - 2
            TextBox7.Text = SelBRY - 2
            TextBox8.Text = SelBRX - SelTLX
            TextBox9.Text = SelBRY - SelTLY
            TextBox10.Text = 0
            TextBox11.Text = -1 'Keeps text from runing off the page.
            TextBox12.Text = SelBRY - SelTLY
            NoUpdateZoom = True
            SelTLX = -1
            SelTLY = -1
        Else
            Beep()
        End If
    End Sub

    Private Function InBounds(ByVal X As Integer, ByVal Y As Integer, ByVal TLX As Integer, ByVal TLY As Integer, ByVal BRX As Integer, ByVal BRY As Integer)
        Return (X >= TLX And X <= BRX And Y >= TLY And Y <= BRY)
    End Function

    Private Sub itmExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmExit.Click
        End
    End Sub

    Private Sub SaveCurrent()
        m_Field(m_Position, 0) = Val(TextBox0.Text) / TexWidth
        m_Field(m_Position, 1) = Val(TextBox1.Text) / TexHeight
        m_Field(m_Position, 2) = Val(TextBox2.Text) / TexWidth
        m_Field(m_Position, 3) = Val(TextBox3.Text) / TexHeight
        m_Field(m_Position, 4) = Val(TextBox4.Text) / TexWidth
        m_Field(m_Position, 5) = Val(TextBox5.Text) / TexHeight
        m_Field(m_Position, 6) = Val(TextBox6.Text) / TexWidth
        m_Field(m_Position, 7) = Val(TextBox7.Text) / TexHeight
        m_Field(m_Position, 8) = Val(TextBox8.Text)
        m_Field(m_Position, 9) = Val(TextBox9.Text)
        m_Field(m_Position, 10) = Val(TextBox10.Text)
        m_Field(m_Position, 11) = Val(TextBox11.Text)
        m_Field(m_Position, 12) = Val(TextBox12.Text)
        m_Field(m_Position, 13) = Val(TextBox13.Text)
    End Sub

    Private Sub itmSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmSelect.Click
        Dim Response As Integer
        Dim TmpName As String

        OpenFileDialog1.Title = "Select TEX File"
        OpenFileDialog1.Filter = "Morrowind Font Texture (*.TEX)|*.TEX"
        If OpenFileDialog1.ShowDialog <> DialogResult.Cancel Then
            TmpName = OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.LastIndexOf("\") + 1)
            If OpenFileDialog1.FileName.Substring(0, OpenFileDialog1.FileName.LastIndexOf("\")) <> FntPath Then
                Response = MessageBox.Show(TmpName + " is not in the same folder as " + FntName + " and must be copied to contniue.", "Warning.", MessageBoxButtons.OKCancel)
                If Response = DialogResult.OK Then
                    FileCopy(OpenFileDialog1.FileName, FntPath + "\" + TmpName)
                Else
                    Exit Sub
                End If
            End If
            SaveCurrent()
            TexName = TmpName.Substring(0, TmpName.LastIndexOf("."))
            ArcImg = ReadTex(FntPath + "\" + TexName + ".tex", True)
            picTex.Image = ArcImg.Clone
            LoadData()
        End If
    End Sub

    Private Sub itmMakeBmp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmMakeBmp.Click
        Dim TempImg As Image

        OpenFileDialog1.Title = "Select TEX File to Convert"
        OpenFileDialog1.Filter = "Morrowind Font Texture (*.TEX)|*.TEX"
        If OpenFileDialog1.ShowDialog <> DialogResult.Cancel Then
            TempImg = ReadTex(OpenFileDialog1.FileName, False)
            SaveFileDialog1.Title = "Save BMP"
            SaveFileDialog1.Filter = "Windows Bitmap Files (*.BMP)|*.BMP"
            SaveFileDialog1.FileName = OpenFileDialog1.FileName.Substring(0, OpenFileDialog1.FileName.IndexOf(".")) + ".BMP"
            If SaveFileDialog1.ShowDialog <> DialogResult.Cancel Then
                TempImg.Save(SaveFileDialog1.FileName, Imaging.ImageFormat.Bmp)
            End If
        End If
    End Sub

    Private Sub itmMakeTex_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmMakeTex.Click
        Dim TempImg As Image
        OpenFileDialog1.Title = "Select BMP File to Convert"
        OpenFileDialog1.Filter = "Windows Bitmap Files (*.BMP)|*.BMP"
        If OpenFileDialog1.ShowDialog <> DialogResult.Cancel Then
            TempImg = Image.FromFile(OpenFileDialog1.FileName)
            SaveFileDialog1.Title = "Save TEX"
            SaveFileDialog1.Filter = "Morrowind Font Texture (*.TEX)|*.TEX"
            SaveFileDialog1.FileName = OpenFileDialog1.FileName.Substring(0, OpenFileDialog1.FileName.IndexOf(".")) + ".TEX"
            If SaveFileDialog1.ShowDialog <> DialogResult.Cancel Then
                If FileSystem.Dir(SaveFileDialog1.FileName) <> "" Then
                    Kill(SaveFileDialog1.FileName)
                End If
                SaveTex(TempImg, SaveFileDialog1.FileName)
            End If
        End If
    End Sub

    Private Sub SaveTex(ByVal MyImage As Image, ByVal FileName As String)
        Dim TexBM As Bitmap, TexPixel As Byte
        Dim ImgCols As Int32, ImgRows As Int32
        Dim TexCol As Integer, TexRow As Integer
        Dim FF_FF_FF As String
        FF_FF_FF = ("").PadRight(3, Chr(255))
        ImgCols = MyImage.Width
        ImgRows = MyImage.Height
        FileOpen(1, FileName, OpenMode.Binary)
        FilePut(1, ImgCols)
        FilePut(1, ImgRows)
        TexBM = New Bitmap(MyImage)
        For TexRow = 0 To ImgRows - 1
            For TexCol = 0 To ImgCols - 1
                FilePut(1, FF_FF_FF) 'White
                TexPixel = TexBM.GetPixel(TexCol, TexRow).R
                FilePut(1, TexPixel)
            Next
        Next
        FileClose(1)
    End Sub

    Private Sub itmHeight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmHeight.Click
        Dim Response As String
        Response = InputBox("Enter new height:", "Font Height", FntHeight.ToString)
        If Response <> "" Then
            FntHeight = Val(Response)
            itmHeight.Text = "Height: " + FntHeight.ToString + " (Change)"
        End If
    End Sub

    Private Sub itmNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmNew.Click
        Dim I As Integer, J As Integer
        Dim Field As Single
        Dim Response As Integer

        Dim TmpFntPath As String
        Dim TmpFntName As String
        Dim TmpTexPath As String
        Dim TmpTexName As String

        SaveFileDialog1.Title = "Create New FNT File"
        SaveFileDialog1.Filter = "Morrowind Font Files (*.FNT)|*.FNT"
        If SaveFileDialog1.ShowDialog <> DialogResult.Cancel Then
            OpenFileDialog1.Title = "Select TEX file."
            OpenFileDialog1.Filter = "Morrowind Font Texture (*.TEX)|*.TEX"
            OpenFileDialog1.InitialDirectory = SaveFileDialog1.InitialDirectory
            If OpenFileDialog1.ShowDialog <> DialogResult.Cancel Then
                TmpFntPath = SaveFileDialog1.FileName.Substring(0, SaveFileDialog1.FileName.LastIndexOf("\"))
                TmpFntName = SaveFileDialog1.FileName.Substring(SaveFileDialog1.FileName.LastIndexOf("\") + 1)
                TmpTexPath = OpenFileDialog1.FileName.Substring(0, OpenFileDialog1.FileName.LastIndexOf("\"))
                TmpTexName = OpenFileDialog1.FileName.Substring(OpenFileDialog1.FileName.LastIndexOf("\") + 1)

                If TmpTexPath <> TmpFntPath Then
                    Response = MessageBox.Show(TmpTexName + " is not in the same folder as " + TmpFntName + _
                            " and must be copied to contniue.", "Warning.", MessageBoxButtons.OKCancel)
                    If Response = DialogResult.OK Then
                        FileCopy(OpenFileDialog1.FileName, TmpFntPath + "\" + TmpTexName)
                    Else
                        Exit Sub
                    End If
                End If

                FntPath = TmpFntPath
                FntName = TmpFntName
                TexName = TmpTexName.Substring(0, TmpTexName.LastIndexOf("."))

                FntHeight = 16
                itmHeight.Text = "Height: 16 (Change)"
                FntHead2 = 1
                FntHead3 = 1
                For I = 0 To m_LastChar
                    For J = 0 To 13
                        m_ArcField(I, J) = 0
                    Next
                    m_ArcField(I, 11) = 2
                Next
                m_Field = m_ArcField.Clone
                FntTail = ("").PadRight(444, Chr(0))
                m_MoveCount = 0
                ArcImg = ReadTex(FntPath + "\" + TexName + ".tex", True)
                picTex.Image = ArcImg.Clone
                m_Position = 0
                EnableSave(True)
                LoadData()
            End If
        End If
    End Sub

    Private Sub itmRevert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmRevert.Click
        Dim Fld As Integer
        For Fld = 0 To 13
            m_Field(m_Position, Fld) = m_ArcField(m_Position, Fld)
        Next
        LoadData()
    End Sub

    Private Sub itmCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmCopy.Click
        Dim Fld As Integer
        For Fld = 0 To 13
            m_ClipField(Fld) = m_Field(m_Position, Fld)
        Next
    End Sub

    Private Sub itmPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmPaste.Click
        Dim Fld As Integer
        For Fld = 0 To 13
            m_Field(m_Position, Fld) = m_ClipField(Fld)
        Next
        LoadData()
    End Sub

    Private Sub itmPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmPrev.Click
        SaveCurrent()
        m_Position -= 1
        LoadData()
    End Sub

    Private Sub itmNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles itmNext.Click
        SaveCurrent()
        m_Position += 1
        LoadData()
    End Sub

    Private Sub EnableSave(ByVal State As Boolean)
        itmSave.Enabled = State
        itmSaveAs.Enabled = State
        itmHeight.Enabled = State
        itmSelect.Enabled = State
        itmRevert.Enabled = State
        itmCopy.Enabled = State
        itmPaste.Enabled = State
        txtSymbol.Enabled = State
        txtPosition.Enabled = State
        mnuNav.Enabled = State
    End Sub

    Private Sub picZoom_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picZoom.MouseMove
        Dim NewH As Integer
        Dim NewW As Integer

        If e.Button = MouseButtons.Left Then
            If picZoom.Cursor Is Cursors.SizeWE Then
                NewW = picZoom.Width + e.X - MagMoveX
                If NewW < 32 Then
                    NewW = 32
                End If
                MagMoveX = MagMoveX + NewW - picZoom.Width
                picZoom.Width = NewW
                gfxZoom = picZoom.CreateGraphics
                gfxZoom.InterpolationMode = Drawing.Drawing2D.InterpolationMode.NearestNeighbor
            End If
            If picZoom.Cursor Is Cursors.SizeNS Then
                NewH = picZoom.Height + e.Y - MagMoveY
                If NewH < 32 Then
                    NewH = 32
                End If
                MagMoveY = MagMoveY + NewH - picZoom.Height
                picZoom.Height = NewH
                gfxZoom = picZoom.CreateGraphics
                gfxZoom.InterpolationMode = Drawing.Drawing2D.InterpolationMode.NearestNeighbor
            End If
            If picZoom.Cursor Is Cursors.SizeNWSE Then
                NewW = picZoom.Width + e.X - MagMoveX
                If NewW < 32 Then
                    NewW = 32
                End If
                MagMoveX = MagMoveX + NewW - picZoom.Width
                picZoom.Width = NewW
                NewH = picZoom.Height + e.Y - MagMoveY
                If NewH < 32 Then
                    NewH = 32
                End If
                MagMoveY = MagMoveY + NewH - picZoom.Height
                picZoom.Height = NewH
                gfxZoom = picZoom.CreateGraphics
                gfxZoom.InterpolationMode = Drawing.Drawing2D.InterpolationMode.NearestNeighbor
            End If
            If picZoom.Cursor Is Cursors.SizeAll Then
                Dim NewX As Integer
                Dim NewY As Integer

                NewX = picZoom.Left + e.X - MagMoveX
                NewY = picZoom.Top + e.Y - MagMoveY

                If NewX < 0 Then
                    NewX = 0
                End If
                If NewX + picZoom.Width > Me.Width Then
                    NewX = Me.Width - picZoom.Width
                End If

                If NewY < 0 Then
                    NewY = 0
                End If
                If NewY + picZoom.Height > Me.Height - HeightDiff Then
                    NewY = Me.Height - HeightDiff - picZoom.Height
                End If

                picZoom.Left = NewX
                picZoom.Top = NewY
            End If
        Else
            If e.X >= picZoom.Width - 8 Then
                If e.Y >= picZoom.Height - 8 Then
                    picZoom.Cursor = Cursors.SizeNWSE
                Else
                    picZoom.Cursor = Cursors.SizeWE
                End If
            Else
                If e.Y >= picZoom.Height - 8 Then
                    picZoom.Cursor = Cursors.SizeNS
                Else
                    picZoom.Cursor = Cursors.SizeAll
                End If
            End If
        End If
    End Sub

    Private Sub picZoom_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picZoom.MouseDown
        If e.Button = MouseButtons.Left Then
            MagMoveX = e.X
            MagMoveY = e.Y
        End If
    End Sub

    Private Sub ResizePicture(ByVal TexWidth As Integer, ByVal TexHeight As Integer)
        picTex.Width = TexWidth
        picTex.Height = TexHeight
        If TexHeight - 4 > 512 Then
            picTex.Top = 0
            If picZoom.Top = 6 Then
                picZoom.Top = 408
                picZoom.Left = 8
            End If
        End If
        If Me.Width < picTex.Left + picTex.Width + 12 Then
            Me.Width = picTex.Left + picTex.Width + 12
        End If
        If Me.Height < picTex.Top + picTex.Height + 8 + HeightDiff Then
            Me.Height = picTex.Top + picTex.Height + 8 + HeightDiff
        End If
    End Sub

End Class