Strip the Ladies

Suddenly female nudity has become quite fashionable in Morrowind.

First and foremost this mod is about gratuitous female nudity. That said, I
tried to make it realistic in a way. Therefor there's aways some kind of reason
for it, but nudity means different things to different people. (Some of these
are obvious, some are reasonable inferences, and some I made up.)

Dark Elves, except for ashlanders, consider partial female nudity a sign of high
status, and so, totally improper for those of low standing... Which only makes
rogues and outcasts like the idea more, of course. Complete nakedness is not seen
as proper for anyone however.

High Elves have similar views, but to them nudity is the mark of a skilled wizard.

Nords are used to extreme cold and often find warmer climates uncomfortable. Plus
they have a remarkable knack for losing their clothes anyway.

Redgards and Wood Elves are more open to nudity as a general rule. Wood Elves in
particular have been known wear highly immodest armor designed to make certain
bodily functions more convenient in the field.

Orcs, at least "civilized" ones, try to dress appropriately, but they aren't used
to making much distinction between the sexes, so most their women think nothing
of being seen topless.

Slaves and prisoners simply may not have been provided with clothing.

Common laborers often find it more convenient to work wearing less. Even some of
the lower class Dunmer women, as long as no Dunmer of high status are around to
complain.

To many Healers the breasts symbolize the nurturing side of magic, and some find
working topless helps to put them in the proper frame of mind.

Some other magic users, for their own strange reasons, insist on do their magic
completely nude.

As the sub-heading indicates, nudity can be fashionable. Particularly in
Mournhold, perhaps due to the tropical climate. Noblewomen are the most likely
to avail themselves of the more daring fashions, and no doubt enjoy knowing
they can get away with it. Ironically clothiers may also be seen wearing very
little, for this reason.

In the Thieves' Guild, a revealing outfit of some kind could even be considered
the "uniform" for female members who sell goods or services. 

The Imperial Cult is also quite open to nudity, chiefly but not only due to
their worship of Dibella.

Mabrigash (a tribe of ashland women) often wear very elaborate yet totally
revealing costumes. Presumably to lure men into their trap.

Vampires may have similar reasons, or maybe they just don't care.

Barbarians, on the other hand, definitely don't care what anyone else thinks. 

And yes, some women are just trying to show off. For example, publicans know an
attractive woman wearing as little a possible is a good way to bring in customers.

"Wait a minute", I hear you saying, "Doesn't that just mean pretty much ALL the
women are naked?" No, actually, it doesn't; You'd be surprised how many women
choose to wear clothes. :p