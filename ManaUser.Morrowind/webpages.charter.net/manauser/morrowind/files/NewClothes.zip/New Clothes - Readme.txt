*****************************************************************

                     The Elder Scrolls III
                           MORROWIND: 
                       New Clothes v1.0

Requires: Morrowind
	   		
*****************************************************************

New Clothes, as in The Emporor's New Clothes. In other words,
this is actually a nude mod. Basically it's Juxtor's Morrowind
Nude Mod plus the female Khajiits from Maboroshi Daikon's Full Nude
Patch, with a few chnages by me. I recomend this for anyone who, for
wantever reason, wants a non-"Better Bodies" nude patch.

Index:
1. Installation
2. Playing the Plug-in
3. Save Games, Compatibility, etc.
4. Known Bugs
5. Credits & Usage

*****************************************************************

     1. INSTALLING THE PLUGIN

*****************************************************************

To install the plugin, unzip the files into the 
Morrowind/Data Files directory. From the Morrowind Launcher,
select Data Files and check the box next to New Clothes.esp. 

*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

Play as normal.

*****************************************************************

     3. Save Games, Compatibility, etc.

*****************************************************************

Shouldn't cause any special problems.

*****************************************************************

     4. Known bugs.

*****************************************************************

Because Bethesda was inconsistant about whether the painted on
underwear counted as naked or not, a few NPCs will appear naked
or topless when probably shouldn't be. See the CoverUp mods in
the Extras folder.

*****************************************************************

     5. Credits & Usage

*****************************************************************

Compiled and modified by ManaUser
paul@manauser.info

Original art, besides Khajiits by Juxtor
juxtor@yahoo.com

Female Khajiit, Maboroshi Daikon
mdaikon@hotmail.com

You may redistribute this mod as you see fit. If you want to use
the art for other purposes, it's fine with me, but you should
ask Juxtor and Maboroshi Daikon first.