This isn't nearly as naughty as it sounds. What this program actually 
does is scan plug-ins (or master files)  for NPCs in less than decent 
attire and output a list. The main use would be making an anti-nude-
mod (like my Cover-Up mods). One notable case it won't catch 
is NPCs equipped only with armor, and lacking the correct skill to 
wear it, although you can tell it to disregard armor entirely.