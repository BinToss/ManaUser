Right, well... what can I say? These are mods to use along with a nude mod if
you want to have more NPCs actually running around naked. Pretty silly, I admit.
But if you don't mind a little silliness, enjoy:

Strip Yokuda.esp - Tribunal required
Yokuda were the people the Redguards came from. So this mod make all Redguards
naked, except for any armor and magic items they had. I picked them because
they're the least common race, but there's a bit of lore background for naked
Redguards too.

Strip Bar.esp - No expansions required
Same idea, this time Barbarians. I guess it's pretty obvious why I targeted them.
I didn't touch Solstheim though, just Vvardenfell; Bloodmoon adds way too many
Barbarians for it to be worth while.

Strip Hlaalu.esp - Tribunal required
If Crassius Curio were Grandmaster... The higher rank a Hlaalu member is, they
less they wear.

Strip by Name.esp - Requires both expansions
The silliest one... All NPCs with "N" names are naked except for whatever armor
they may be wearing. And NPCs with "T" names are topless, and all NPCs with "B"
names are bottomless. Effectivly this just means random nudity.

Strip The Ladies.esp - Requires both expansions
(See seperate Readme for details.)
This is the only one of the bunch I really put much thought into. But I still
don't consider it a "real" mod. To be one, it would need a good deal of new
dialog to fit the nudity into the game world, and probably some more male
nudity to balence it out.

FemGuards Deluxe.esp - Requires both expansions
Inspired by Aaron Potter's original FemGuards. I don't know if he designed
that with nude mods in mind or if the nudity that resulted from the
combination was an accident, but I decided to go all out and make a
for-sure-intentionally-nude version. What it does is turn all generic (unnamed)
guards female and give them customized suits of armor that are revealing to
various degrees. Guards who started out female (including unique ones) have
been similarly treated.

New Additions:

Topless Ashlanders.esp - No expansions required
I left the Ashlanders out of Strip The Ladies, just as a way to distinquish
the cultures more, but the reverse makes at least as much sense. In this mod,
all female Ashlanders are topless. Also a few of the old fashioned Veltothi
women. This one even has a quest, though it's really more like an overblown
easter egg. If you don't feel like waiting to stumble on it:
<-- .dnuora kool dna arom let ni tnanevoc eht tisiV <--

Sexist guards.esp - Requires both expansions
This is a mashup of FemGuards, and another mod of mine, Mixed Guards. In
this version, only some of the generic guards are replaced by women. But the
new female guards, as well as guards who were already female are dressed in
highly revealing armor, while the men still have their old suits. I felt a
little guilty about this one since it's not as obviously silly as FemGuards,
but still really sexist. So I threw in a book with a rather long but hopefully
amusing story explaining the situation.

Topless Redheads.esp - Requires both expansions
This one is just another quickie. It seems the Emperor likes redheads and he
wanted to pass a law that redheads may not wear helmets. But there was some
kind of misunderstanding, because the law, as entered in the books, says women
with red hair must be topless.


Okay, there you have it. Fair warning, I made these just for the heck of it, so
they haven't been tested as well or cleaned as well as I normally would. Plus
by their nature, they change many NPCs which is always risky for compatibility,
as well as necessitating starting a new game for full effect. But if you still
want to give one or more of them a try, I suggest do it in the same spirit I made
the mods, just a fun diversion, not something you have been plans for. I don�t
REALLY think there are any killer bugs mind you, but you never know.

I also recommend using only one or perhaps two at a time. Not for compatibility
reason, but because I think it's more fun. If you were to use ALL these mods,
you'd just end up with a whole bunch of naked people. If that's what you want,
fine, I'm not going to judge you. :-) But personally, I think it's more
interesting if it's a little rare.