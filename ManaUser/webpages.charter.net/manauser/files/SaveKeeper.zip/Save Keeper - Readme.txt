**********************************************************************

                  Save Keeper for Morrowind v0.1 Beta

**********************************************************************

Here's the deal. The main purpose of this program was to rename 
QuickSave files, on the theory that saving over existing save is the 
main source of corruption. But based on information from other Elder 
Scrolls forum members I now have reason to doubt this premise was 
correct. But if you think you might have a use for it anyway, be my 
guest. It does have a few other features. The rest of the readme is 
presented as originally written.

**********************************************************************

     1. BASIC INSTRUCTIONS

**********************************************************************

Before you do anything else, I suggest you back up your save games. 
Just in case. This is beta software after all. It seems reliable 
enough, but you never know what bugs could be lurking.

The next thing you need to do is put Save Keeper.exe in your Morrowind 
folder. That's "C:\Program Files\Bethesda Softworks\Morrowind" by 
default, or if you installed Morrowind to a different path, it should 
be wherever Morrowind.exe is located. Now double-click Save Keeper.exe 
to launch it. At this point, you could start playing Morrowind right 
away, but first, you might want to right-click on the icon that 
appeared in your system tray (usually at the bottom right part of the 
screen) and use the Make Shortcut option to either put an icon on the 
Desktop so you can start it Save Keeper more conveniently next time, 
or make a shortcut in the Startup section of the Start Menu so it will 
run automatically. 

Anyway, once Save Keeper is running, you just start Morrowind and play 
as normal. Well almost. Because Save Keeper renames your Quicksave to 
give you a fresh slot for next time, you can't use Quickload. You can 
load your Quicksave from the Load command on the main menu instead. If 
you press F9, it will act like pressing ESC instead, to remind you of 
this.

When you Quicksave or when an Autosave is made, you will either hear 
the "OK Sound" (a page turning) to indict your save was successfully 
renamed, or the "Fail Sound" (a sad meow) to indicate something has 
gone wrong. (Both sounds are from Morrowind and can be changed, more 
on that in a bit.) In the unlikely event you hear the Fail Sound, you 
can press Ctrl+Alt+R to try again, but if that doesn't work, you 
should probably exit Morrowind and try to figure out what's wrong. It 
could be that one of your Quicksave files is marked Read Only for 
example.

And that's all you need to know. Just remember to make sure Save 
Keeper is running when you play Morrowind, and remember not to re-use 
regular save slots, because Save Keeper doesn't protect those. It does 
however have a feature for removing old saves so you won't have to go 
into Windows Explorer to do it. This feature is explained in the next 
section.

**********************************************************************

     2. ADVANCED FEATURES

**********************************************************************

If you want to use the extra features, the first thing you should know 
is how to edit Save Keeper.ini. This file is automatically created in 
the same directory as Save Keeper.exe, if it does not already exist. 
It's just a text file and can be opened with Notepad (just like 
Morrowind.ini), but you can also edit it by right-clicking Save 
Keeper's tray icon and selecting Configure. One advantage to doing it 
that way is that Save Keeper will automatically restart itself close 
the edit window. Otherwise your changes won't take effect until the 
next time you start Save Keeper.

The default Save Keeper.ini file looks like this:
-------------------------------------------------
Configuration file for Save Keeper v0.1 Beta
For details, see the Readme.

[Startup]
BetaWarning=1
;StartApp1=Morrowind Launcher.exe
;StartApp2=C:\Program Files\Example\Foo.exe

[General]
Recycle=0
DupDelete=0
QuitWithGame=0
ExtraHotkeys=1
MirrorKeys=0

[Sound]
OKSound=Data Files\Sound\Fx\item\bookpag2.wav
FailSound=Data Files\Sound\Cr\kgout\scrm2.wav
-------------------------------------------------

I'll just go through each line and tell you what they do. First the 
Startup section:
  
BetaWarning
This just controls giving you a warning message that this is beta 
software. 1 means on, 0 means off. It will automatically turn off when 
you see the message.

;StartApp1
The ; at the beginning means this won't actually do anything. But if 
you take that out, what this will do is launch some other program when 
you start Save Keeper. Having it start the Morrowind Launcher is the 
obvious example, but you might have other programs like FPS Optimizer. 
You can  use an absolute path, a relative path, or just the program 
name if it's in the same directory. I allowed for up to 9 StartApp 
lines, just in case you need that many. Make sure they each has a 
different number.

If you put a ~ at the end on an AppStart line, Save Keeper will only 
run that program if it isn't already running. You can also add a ~ 
followed by the file name of another program to skip the AppStart line 
when that program is running. For example:
StartApp2=C:\Program Files\Example\Foo.exe~Bar.exe
would start Foo.exe, unless Bar.exe is running. And you can combine 
the two. Here's practical example:
StartApp1=Morrowind Launcher.exe~Morrowind.exe~
That will start the Morrowind Launcher, unless either it, or Morrowind 
itself is running (notice the second ~ at the end).

On to the General section:

Recycle (Default: 0)
If you set this to 1, old Quicksaves and Autosaves will be moved to 
the recycle bin instead of being deleted. It's basically an extra 
safety feature.

DupDelete (Default: 0)
This is the most important "extra" feature, but a potentially 
dangerous one, so it's turned off by default. Here's how it works. 
Right after you save in a regular slot, you press Ctrl+Alt+D and Save 
Keeper will remove any older save slots with the same name. It must be 
exactly the same, except for capitalization. So "My barbarian" is the 
same as "My Barbarian", but "My barbarian 2" is not. If it removes at 
least one save slot you will hear the OK Sound, if not, the Fail 
Sound. As you probably guessed setting DupDelete to 1 will turn this 
feature on.

One limitation of this is that it won't recognize save slots that have 
previously been renamed. That's because the file name won't match the 
save name in this case. You can force Save Keeper to read the save 
name from EVERY save file, which solves this, but is much slower. 
Since the main point of using Save Keeper is NOT to reuse save slots, 
I don't think it's normally worth it. But if you want to, you can 
enable this by setting  DupDelete to the word "Slow" (that is, 
DupDelete=Slow).

Finally, For safety sake, saves removed by this command will go to the 
Recycle Bin even when Recycle is set to 0. If you're sure you would 
like them to be deleted, you can set Recycle to "Never".

QuitWithGame  (Default: 0)
This will make Save Keeper automatically close when you close 
Morrowind.

ExtraHotkeys  (Default: 0)
This enables some extra commands, which I admit have nothing to do 
with save games. Set this to 0 to disable them. Most of these are 
macros for typing console commands, be sure to open the console with
the (~ key) before using them.

ALT+1	Player->
ALT+A	AddItem
Shift+Alt+A	AddSpell
Alt+R		RemoveItem
Shift+Alt+R	RemoveSpell
Alt+G (Give)	Player->AddItem
Shift+Alt+G	Player->AddItem "Gold_001"
Alt+P		PlaceAtPC
Shift+Alt+P	PlaceAtMe (Requires Bloodmoon)
Alt+S		StartScript (Great with my Morrowind Toolkit mod)
Alt+F		AiFollow Player
Alt+W		AiWander (Or stand still)
Alt+K (Kill)	SetHealth 0
Alt+H (Heal)	ModCurrentHealth 9999
Alt+E		Enable
Alt+D		Disable
ShiftAlt+D	SetDelete 1 (Tribunal or Bloodmoon)
Ctrl+Alt+M	Minimize Morrowind (Not a console command)

Be careful with that last one. On some systems, switching out of 
Morrowind can cause it to crash. If you minimized Morrowind and can't 
get it back, try right-clicking its button on the taskbar and 
selecting Restore.

MirrorKeys (Default: 0)
Morrowind treats the left and right modifier keys (meaning Shift, Ctrl 
and Alt) as separate keys. I prefer that the left and right keys work 
the same. Setting this to 1, well make all the modifier keys work like 
the left keys. You can also set it to the word "Right" to make all the 
modifier keys work like the right keys.

Finally, the Sound section:

OKSound (Default: Data Files\Sound\Fx\item\bookpag2.wav)
This is changes the sound you hear when something works right. You can 
use an absolute path, a relative path, or just the sound file name if 
it's in the same directory. There's plenty of sounds form Morrowind to 
choose from, or you could use something else entirely. If you set 
OKSound to nothing, no sound will play. 

FailSound (Default: Data Files\Sound\Cr\kgout\scrm2.wav)
This is changes the sound you hear when something goes wrong. It works 
just like the above, except if you set it to nothing, a standard error 
sound from Windows will be used.

And that's all there is to it. :-)

**********************************************************************

     3. CREDITS, CONTACT INFO & USAGE PERMISSION

**********************************************************************

Created by Paul Pliska A.K.A. ManaUser
email: paul@manauser.info
website: http://webpages.charter.net/manauser/morrowind/
or alternatively: http://manauser.info/morrowind/

A big thanks to Chris Mallett, creator of AutoHotKey, the excellent 
macro and scripting language Save Keeper was made with.
And it's free too, check it out:
http://www.autohotkey.com

You may use this software in any way you see fit. Just be sure to
pass on the warning that it may not be  actually provide any
protection for save games.

If you want the source code (in AutoHotKey script) just ask.