Virtual God Detector 1.0

What is it?

Virtual God Detector can be used alone to help answer that age old question, or you can use it to double-check, when you think something else might be a message from God.

How does it work?

OK, it doesn't exactly detect God. But it does give him a nice simple way to let you know he's there. What it does is set a bit to zero, and repeatedly check if God has changed it to a one. Probably the smallest miracle anyone's ever asked for.

Tips

If you want Virtual God Detector to run when you start Windows, put a shortcut to it in the Programs->Startup section of your Start Menu.

Instead of using the right-click menu, you can hide or show the detector window by double-clicking it or the tray icon.

Custom background images should ideally be 160x120, but Images of other sizes will be stretched to fit.

Important!

If this program doesn't work, chances are it's because you don't have the .Net Frame work. You can get it through Windows Update or here:

http://www.microsoft.com/downloads/details.aspx?FamilyID=262d25e3-f589-4842-8157-034d1e7cf3a3&displaylang=en

Created by Paul Pliska (email: paul@manauser.info)
A big thanks to Dean Booth of Yo-God.com for creating the original God Detector that gave me the idea and for giving me permission to make this electronic version.

This program may be freely distributed.