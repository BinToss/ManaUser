*****************************************************************

                      The Elder Scrolls III
                            MORROWIND: 
                 Ahnassi Romance Special Edition

Requires Tribunal OR Bloodmoon for scripting functions.
	   		
*****************************************************************

This special edition is inspired by an initiative on California's 
ballot this week. Prop 8 would change the state's constitution to 
forbid same sex couples from getting married, reversing a 
decision by the state Supreme Court.

So... I've updated this mod to allow female characters to romance 
Ahnassi too. There are other minor enhancements as well.

           Vote NO on Prop 8! Do it for the lesbians.

Index:
1. Installation
2. Playing the Plugin
3. Save Games and Compatibility
4. Known Bugs
5. Credits & Usage

*****************************************************************

     1. INSTALLING THE PLUGIN

*****************************************************************

To install the plug-in, unzip Ahnassi-SE.esp into the
Morrowind\Data Files directory. Then, from the Morrowind
Launcher, select Data Files and check the box next to that file.

If you are currently using the old Ahnassi.esp, uncheck it.

*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

Just pay Ahnassi a visit. If you've already completed all her
original quests something new should open up.

Hint: Hang out in her house for a while.

*****************************************************************

     3. Save Games and Compatibility.

*****************************************************************

Safe to add to an existing game.

*****************************************************************

     4. Known bugs.

*****************************************************************

Nothing particular.

*****************************************************************

     5. Credits & Permision

*****************************************************************

Created by ManaUser
paul@manauser.info

You may use anything from this mod, credit is appreciated but
optional. That means you can redistribute the whole thing too,
though in that case, I sure hope you give me credit. :)