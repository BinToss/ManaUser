This Adds Graphic Herbalism behavior to Morrowind Crafting
plants, namely Kelp and the "Sausage Plant". It also gives the
ingredients from those plants new graphics that look more like
the plant parts they're supposed to be.

Make sure this loads after Morrowind Crafting itself.

Requires Graphic Herbalism... and Morrowind Crafting.
(As if that wasn't obvious).
