JoyTail 1.0.1 Beta

This is a "Remote Sensor" program for Scratch that lets you use a 
joystick. It also works with gamepads, so when I talk about joysticks 
from now on, I mean gamepads too. It should work with any joystick 
supported by Windows.

HOW TO INSTALL:

Just copy JoyTail anywhere.
You could put it in your Scratch folder

HOW TO USE:

1. Start Scratch.
2. Click the Sensing button.
3. Right-click the ([slider] sensor value) block.
4. Select "enable remote sensor connections".
5. Make sure your joystick is connected.
6. Start JoyTail.
7. Look for a new icon in the system tray (down by the clock).
8. Click on it to connect JoyTail to Scratch.

Note! You must repeat steps 3, 4 and 8 if you open a new project.

WHAT IT DOES:

When you press a button on the joystick it will send a broadcast to 
Scratch. It will send Joy1 for the first button, Joy2 for the second 
button, and so on, up to Joy 32 (if you have that many buttons).

Also, JoyX and JoyY will appear on the sensor value block.
These tell what position the joystick is in.

JoyX is the horizontal position.
-100 means left, 0 means center and 100 means right.

JoyY is the vertical position.
-100 means bottom, 0 means center and 100 means top.

Depending on what kind of joystick you have, they might show other 
numbers in between.

The buttons appear on the sensor value block too.
1 means the button is pressed, and 0 means it isn't.

Created by ManaUser
Written in AutoHotkey