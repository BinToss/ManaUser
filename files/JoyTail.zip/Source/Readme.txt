This is the code I used to make JoyTail. Feel free to experiment 
with it. You will need to download AutoHotkey to use this.

I highly recommend it. JoyTail is pretty complicated, but you can 
make simple programs in AutoHotkey that are still really useful. 
It's almost as easy to use as Scratch.

You can get it here:
http://www.autohotkey.com/
