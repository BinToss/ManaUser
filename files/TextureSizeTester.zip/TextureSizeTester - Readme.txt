Version 2 (Now with Text Labels)

This is a "tool" to help you decide what size texture to use on a model.

INSTRUCTIONS:
Give your mesh this specially made DDS texture and load it in the 
game. Stand as close to it as you normally would during play, and see 
what color it is. This will tell you the largest texture size to use, 
any more would be wasted. It doesn't necessarily mean you need one 
that big. Remember, going up one size makes your file four times 
bigger. On the other hand, hardware matters too. Someone with a higher 
resolution screen might be able to see more detail.

  COLOR KEY
Red     = 4096
Yellow  = 2048
Green   = 1024
Cyan    = 512
Blue    = 256
Magenta = 128
White   = 64
Black/B = 32
Black/G = 16
Black/R = 8
Black   = Tiny

Sizes 64 and above have black text labels.
Sizes 32 and below have colored dots.

Note: The object will probably appear rainbow-hued, so read the
value of the "highest" color that appears in significant quantity.