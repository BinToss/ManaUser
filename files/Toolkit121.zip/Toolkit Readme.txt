*****************************************************************

     The Elder Scrolls III
           MORROWIND: 
     Morrowind Toolkit v1.21

Requires Tribunal OR Bloodmoon, for scripting functions.
	   		
*****************************************************************

This is a collection of scripts and spells which I find handy for
testing mods. They can also be used as cheats or for working
around weird bugs that crop up while playing.

Index:
1. Installation
2. Playing the Plugin
3. Save Games and Compatibility
4. Known Bugs
5. Credits & Usage

*****************************************************************

     1. INSTALLING THE PLUGIN

*****************************************************************

To install the plugin, unzip the file(s) into the 
Morrowind/Data Files directory. From the Morrowind Launcher,
select Data Files and check the box next to Toolkit.esp. I
would go ahead and load it every time you play, just in case you
need it, but it's up to you.

*****************************************************************

     2. PLAYING THE PLUGIN

*****************************************************************

Open the console (press ~), click a target object
(if applicable), type StartScript Toolkit and press enter.

That will bring up the "main menu" script. Use the "Prev" and
"Next" buttons to select a feature and then click " *Activate*"
to use it, or "Quit" to cancel.

Most are scripts can also be started directly with
StartScript "Name", and either stop themselves after they do
their thing or can be stopped by typing StopScript "Name".
Anything with "spell" in its name, can be added with and removed
with Player->AddSPell "Name" and Player->RemoveSPell "Name"
respectively. and TopicPower is a global which you can turn on
by setting it to 1 and turn off by setting it to 0. But all of
this can be done through the ToolKit script if you prefer.
There is also a global variable, ShowNow is which is used by
typing set ShowNow to Something.

Add1MGold:
Gives PC 1 million gold. Handy if you need more gold that can be
added by a single AddItem command.

ArmorCheck: *New in v1.21*
Shows target NPC's armor skills and can temporarily set yours to
match. This lets you see the armor rating of different items as
that NPC would. You can also check the total AC that NPC would
have wearing a given suit (by trying it on yourself). This would
mainly be useful with companions. Also remember that the
Unarmored Bug effects NPCs too. Unarmored *doesn't work* unless
at least one piece of armor is worn.

IMPORTANT: Don't end ArmorCheck with StopScript! Just Sneak.
Or you can do it through Toolkit or use StopAll.

AquaSpell:
Water Breathing and Swift Swim for convenient testing of
underwater areas.

Cheat:
Sets all the PC's stats and skills to 50 and Health and Magicka
to 100. If you don't want your test character to suck so bad.

Clock:
Shows current hour and a timer in both real time and game time.
Format is Curent Time ( Real Seconds / Game Hours + Game Days ).

ClockReset:
Resets the timer on the Clock script.

Fill:
Prints a blank MessageBox every frame. Used to improve
readability of other MessageBox scripts.

Immortal:
Gives the target Dagoth Ur style immortality. Meaning their
health is set to 65000 every frame. Note that it will not be set
back to normal then this script ends.

KillAll:
Creates a huge explosion around the PC, who will, of course, be
protected.

KillSpell:
A free spell the PC can use to quickly dispatch annoying NPCs and
creatures.

ReloadActor:
Replaces an NPC or creature with a fresh copy from the esp/esm
definition. Actually it kills and Resurrects them so be careful
if their death (or life) is important in a quest or script.

MovePCTo:
Very handy, moves the PC to the target object selected in the
console.

MoveToPC:
Moves the target object selected in the console to the PC. Good
for NPCs who leave their posts.

PhotoSpell:
A combination of Levitation and Night Eye. Handy for taking
screenshots.

ShowDamage:
Shows the damage taken when the target's Health is injured.
Doesn't work well with spells.

ShowMode:
Shows which if any of the following are true: PC is jumping,
running, sneaking, or a menu is open. I can't remember what this
is good for. ;p

ShowNow:
A global variable. Set it to a function or mathematical formula
to see the result at once.

ShowStats:
Shows the target's Health, Magicka and Fatigue.

StopAll:
Stops all scripts. Well all of these utility scripts anyway.
Specifically, ArmorCheck, Clock, Tracker, Fill, Immortal,
ShowMode, ShowStats and ShowDamage.

SuperCheat:
Like Cheat only more so. Sets all the PC's stats and skills to
100, Health, Magicka and Fatigue to 1000 and gives you 65535 gold
and sets Reputation to 100, which makes persuasion very easy.

TopicPower:
A global variable. Set it to 1 to enable "topic based services"
with all NPCs. Topic based services? Yes. What that does is show
most of the Vendor type services on the topic list at the right
when you talk to an NPC. Barter and Travel don't work this way,
so I left them out. Companion Share (or just Share, depending on
which expansions and mods you have), comes out as a strange
combination of pick-pocketing and looting a corpse, but it could
still be useful. Spells will list things that shouldn't be fore
sale, like racial abilities, but otherwise works. Training,
Repair, Spellmaking and Enchanting all work perfectly.

TopicPower also enables the topic "(Un)Equip Items"
to work around the funny way Companion Share works. Be sure you
tell them to equip their items again or they'll just keep walking
around naked.

Tracker:
Shows the target's current distance from the PC. You can use
"TargetID"->StartScript Tracker if you can't see the target,
however it must be in the same cell (or a neighboring cell if
you're outside).

WeightFix:
If you find your encumbrance is too high or low, this will
semi-automatically fix it. Here's how it works: You drop
everything you can, then total up the weight of what's left (if
anything). Don't forget to include Burden and Feather effects.
(Feather should be subtracted, so the total could be negative in
that case.) Use the adjust button to enter this number, then
click Begin. Now begin running forwards so the script can tell
if you're over-encumbered as it experiments with your weight.
Keep running until it says you're done. Now just pick up your
stuff. You'll run in place so don't worry about having a lot of
space, but do be sure you're not RIGHT next to a wall or
anything.

*****************************************************************

     3. Save Games and Compatibility.

*****************************************************************

Saves shouldn't be a problem. The only compatibility problem I
can foresee, besides the fact that if you cheat while playing a
mod, you may screw it up, is that I didn't put my initials before
the script names as I normally would, since I wanted them to be
convenient to type. If someone else named a script or whatever
"Clock" for example then that mod would be incompatible.

*****************************************************************

     4. Known bugs.

*****************************************************************

None, besides the quirks I've already mentioned.

*****************************************************************

     5. Credits & Usage

*****************************************************************

Created by ManaUser
paul@manauser.info

You may use anything from this mod, credit is appreciated but
optional. That means you can redistribute the whole thing too,
though in that case, I sure hope you give me credit. :)